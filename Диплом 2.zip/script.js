
 function showTel(){
document.getElementById("info").style.display="none";
document.getElementById("table2").style.display="none";
document.getElementById("table3").style.display="none";
document.getElementById("table").style.display="block";
 }
 function showPlan(){
document.getElementById("info").style.display="none";
document.getElementById("table").style.display="none";
document.getElementById("table3").style.display="none";
document.getElementById("table2").style.display="block";
 }
  function showNout(){
document.getElementById("info").style.display="none";
document.getElementById("table").style.display="none";
document.getElementById("table2").style.display="none";
document.getElementById("table3").style.display="block";
 }
 