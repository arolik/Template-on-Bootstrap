function registr(){
	login=document.getElementById('name').value;
	if(login.length<=2){
		alert("мало букв");
		return;
	}
		
	password=document.getElementById('pas').value;
	if(password.length<=4){
		alert("мало букв");
		return;
	}
	
	slovo=document.getElementById('word').value;
	if (slovo.length<=4) {
		alert("мало букв");
		return;
	}
	
document.getElementById("enter").style.display="block";
document.getElementById("vhod").style.display="none";
}
function add() {
	if (pizza1.checked==true) {
		var piz1=parseInt(pizza1.value)
	}
	else var piz1=0;
	if (pizza2.checked==true) {
		var piz2=parseInt(pizza2.value)
	}
	else var piz2=0;
	if (pizza3.checked==true) {
		var piz3=parseInt(pizza3.value)
	}
	else var piz3=0;
	if (pizza4.checked==true) {
		var piz4=parseInt(pizza4.value)
	}
	else var piz4=0;
	if (pizza5.checked==true) {
		var piz5=parseInt(pizza5.value)
	}
	else var piz5=0;
	tp=piz1+piz2+piz3+piz4+piz5;
	totalprice.value=tp;
}