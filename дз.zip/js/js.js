function add(){
	my.inf.value=my.inf.value+my.name.value+"\n";
	my.inf.value=my.inf.value+my.name2.value+"\n";
	my.inf.value=my.inf.value+"возраст:"+my.age.value+"\n";
	var elements=document.getElementsByName("gender");
	for(var i=0, len=elements.length; i<len; ++i)
	{if(elements[i].checked){
		my.inf.value=my.inf.value+"пол:"+elements[i].value+"\n";
	}
	}
	if(my.c1.checked==true)
		my.inf.value=my.inf.value+"английский\n";
	if(my.c2.checked==true)
		my.inf.value=my.inf.value+"немецкий\n";
	if(my.c3.checked==true)
		my.inf.value=my.inf.value+"суржик\n";
	my.reset1.disabled=false;
}